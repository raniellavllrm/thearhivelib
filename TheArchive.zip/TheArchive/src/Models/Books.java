/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import thearchive.MysqlConn;

/**
 *
 * @author raniellavillarama
 */
public class Books {

    public int AccessionNumber;
    public String BookName;
    public String BookAuthorSName;
    public String BookAuthorFName;
    public String BookAuthorMName;
    public String BookAuthor;
    public String ISBN;
    public String BookAvailability;
    public int AvailStat;

    public Books(int accession_number, String book_name, String bookauthor, String bookauthor_sname, String bookauthor_fname, String bookauthor_mname, String isbn, String book_availability) {
        this.AccessionNumber = accession_number;
        this.BookName = book_name;
        this.BookAuthor = bookauthor;
        this.BookAuthorSName = bookauthor_sname;
        this.BookAuthorFName = bookauthor_fname;
        this.BookAuthorMName = bookauthor_mname;
        this.ISBN = isbn;
        this.BookAvailability = book_availability;
        if (book_availability.equalsIgnoreCase("available")) {
            this.AvailStat = 1;
        } else if (book_availability.equalsIgnoreCase("borrowed")) {
            this.AvailStat = 2;
        }
    }
    private static Connection conn = MysqlConn.getConnection();

    public static ArrayList<Books> getBooks() {
        try {
            ArrayList<Books> books = new ArrayList<>();
            String query = "SELECT * FROM books";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                //System.out.println(rs.getString("name"));
                books.add(new Books(rs.getInt("accession_number"), rs.getString("book_name"), rs.getString("book_author"), rs.getString("book_snameauthor"), rs.getString("book_fnameauthor"), rs.getString("book_mnameauthor"), rs.getString("isbn"), rs.getString("book_availability")));
            }
            st.close();
            return books;
        } catch (SQLException e) {
            return null;
        }
    }

    public static boolean createBook(String entBook, String entSName, String entFName, String entMName, String entISBN, String entBookAvail) {
        try {

            String query = "INSERT INTO books (book_name, book_author, book_snameauthor, book_fnameauthor, book_mnameauthor, isbn, book_availability)" + "values (?,?,?,?,?,?,?)";
            PreparedStatement insertQuery = conn.prepareStatement(query);
            String entName = entSName + ", " + entFName + " " + entMName + ".";
            insertQuery.setString(1, entBook);
            insertQuery.setString(2, entName);
            insertQuery.setString(3, entSName);
            insertQuery.setString(4, entFName);
            insertQuery.setString(5, entMName);
            insertQuery.setString(6, entISBN);
            insertQuery.setString(7, entBookAvail);
            insertQuery.execute();
            System.out.println("Insert into table 'books' Successful.");
            return true;
        } catch (SQLException e) {
            return false;

        }
    }

    public static boolean updateBook(int accessionNumber, String entBook, String entSName, String entFName, String entMName, String entISBN, String entBookAvail) {
        try {
            String entName = entSName + ", " + entFName + " " + entMName + ".";
            String query = "UPDATE books set book_name =(?), book_author =(?), book_snameauthor =(?), book_fnameauthor = (?), book_mnameauthor = (?), isbn = (?), book_availability =(?) where  accession_number = (?)";
            PreparedStatement updateQuery = conn.prepareStatement(query);
            updateQuery.setString(1, entBook);
            updateQuery.setString(2, entName);
            updateQuery.setString(3, entSName);
            updateQuery.setString(4, entFName);
            updateQuery.setString(5, entMName);
            updateQuery.setString(6, entISBN);
            updateQuery.setString(7, entBookAvail);
            updateQuery.setInt(8, accessionNumber);
            updateQuery.execute();
            System.out.println("Update table 'books' Successful.");
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public static Books getBooksByAccNum(int accNum) {
        try {
            Books books = null;
            String query = "SELECT * FROM books where accession_number = " + accNum;
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                books = new Books(rs.getInt("accession_number"), rs.getString("book_name"), rs.getString("book_author"), rs.getString("book_snameauthor"), rs.getString("book_fnameauthor"), rs.getString("book_mnameauthor"), rs.getString("isbn"), rs.getString("book_availability"));
            }
            st.close();
            return books;
        } catch (SQLException e) {
            return null;
        }
    }

    public static boolean deleteBook(int accessionNumber) {
        try {
            Books book = getBooksByAccNum(accessionNumber);
            String query = " DELETE from books where accession_number = " + accessionNumber;
            PreparedStatement deleteQuery = conn.prepareStatement(query);
            deleteQuery.execute();
            query = " DELETE from transactions where accession_number ='" + accessionNumber + "'";
            deleteQuery = conn.prepareStatement(query);
            deleteQuery.execute();
            System.out.println("Delete from table books Successful");
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public static ArrayList<Books> searchNumBooks(String accNumSearch, String isbnSearch) {
        try {
            ArrayList<Books> books = new ArrayList();
            String query = "SELECT * FROM books where ";
            if ((!accNumSearch.isEmpty()) && isbnSearch.isEmpty()) {
                query = query + "accession_number REGEXP '" + accNumSearch + "'";
            } else if ((accNumSearch.isEmpty()) && !isbnSearch.isEmpty()) {
                query = query + "isbn REGEXP '" + isbnSearch + "'";
            } else if ((!accNumSearch.isEmpty()) && !isbnSearch.isEmpty()) {
                query = query + "accession_number REGEXP '" + accNumSearch + "' AND isbn REGEXP '" + isbnSearch + "'";
            }
            System.out.println(query);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                books.add(new Books(rs.getInt("accession_number"), rs.getString("book_name"), rs.getString("book_author"), rs.getString("book_snameauthor"), rs.getString("book_fnameauthor"), rs.getString("book_mnameauthor"), rs.getString("isbn"), rs.getString("book_availability")));
            }
            st.close();
            return books;
        } catch (SQLException e) {
            return null;
        }
    }

    public static ArrayList<Books> searchTextBooks(String bookName, String bookAuthor) {
        try {
            ArrayList<Books> books = new ArrayList();
            String query = "SELECT * FROM books where ";
            if ((!bookName.isEmpty()) && bookAuthor.isEmpty()) {
                query = query + "book_name REGEXP '" + bookName + "'";
            } else if ((bookName.isEmpty()) && !bookAuthor.isEmpty()) {
                query = query + "book_author REGEXP '" + bookAuthor + "'";
            } else if ((!bookName.isEmpty()) && !bookAuthor.isEmpty()) {
                query = query + "book_name REGEXP '" + bookName + "' AND book_author REGEXP '" + bookAuthor + "'";
            }
            System.out.println(query);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                books.add(new Books(rs.getInt("accession_number"), rs.getString("book_name"), rs.getString("book_author"), rs.getString("book_snameauthor"), rs.getString("book_fnameauthor"), rs.getString("book_mnameauthor"), rs.getString("isbn"), rs.getString("book_availability")));
            }
            st.close();
            return books;
        } catch (SQLException e) {
            return null;
        }
    }

    public static ArrayList<Books> searchBooks(String textSearch) {
        try {
            ArrayList<Books> books = new ArrayList();
            String query = "SELECT * FROM books where accession_number LIKE '" + textSearch + "%' OR book_name REGEXP '" + textSearch + "' OR book_author REGEXP '" + textSearch + "'OR isbn REGEXP '" + textSearch + "'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                books.add(new Books(rs.getInt("accession_number"), rs.getString("book_name"), rs.getString("book_author"), rs.getString("book_snameauthor"), rs.getString("book_fnameauthor"), rs.getString("book_mnameauthor"), rs.getString("isbn"), rs.getString("book_availability")));

            }
            st.close();
            return books;
        } catch (SQLException e) {
            return null;
        }
    }
    
    public static boolean updateBookStatus(int accNum) {
        try {
            String query = "UPDATE books set book_availability = (?) where accession_number = (?)";
            PreparedStatement updateBook = conn.prepareStatement(query);
            updateBook.setString(1, "Available");
            updateBook.setInt(2, accNum);
            updateBook.execute();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String returnBookName(int accNum) {
        String bookName = getBooksByAccNum(accNum).BookName;
        return bookName;
    }

}
