package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import thearchive.MysqlConn;

public class Admin {

    private static String AdminUN;
    private static String AdminPass;
    private static String[][] Admin = {{"superadmin", "admin"}};

    public Admin(String adminun, String adminpass) {
        this.AdminUN = adminun;
        this.AdminPass = adminpass;
    }
    private static Connection conn = MysqlConn.getConnection();

    public static void createAdmin() {
        try {
            String query = "INSERT INTO admin (admin, admin_password)" + "values (?,?)";
            PreparedStatement insertQuery = conn.prepareStatement(query);
            for (int x = 0; x < Admin.length; x++) {
                int n = 0;
                for (int y = 0; y < Admin[x].length; y++) {
                    n = n + 1;
                    insertQuery.setString(n, Admin[x][y]);
                }
            }
            insertQuery.execute();
        } catch (SQLException e) {
            System.out.println("Error in inserting admin in Admin table");
        }
    }

    public static Boolean checkAdmin(String username, String password) {
        ArrayList<Admin> admin = new ArrayList<>();
        admin = getAdmin();
        for (int x = 0; x < admin.size(); x++) {
            if (username.equals(admin.get(x).AdminUN) && password.equals(admin.get(x).AdminPass)) {
                return true;
            }
        }
        return false;
    }

    public static ArrayList<Admin> getAdmin() {
        ArrayList<Admin> admin = new ArrayList<>();
        String query = "SELECT * FROM admin";
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                //System.out.println(rs.getString("name"));
                admin.add(new Admin(rs.getString("admin"), rs.getString("admin_password")));
            }
            st.close();
            return admin;
        } catch (Exception e) {
            return null;
        }
    }
}
