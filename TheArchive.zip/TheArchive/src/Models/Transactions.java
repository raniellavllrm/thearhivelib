/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import thearchive.MysqlConn;
import thearchive.TheArchive;

public class Transactions {
    public  int TransactionNum;
    public  int StudentID;
    public  String BorrowerName;
    public  int AccessionNumber;
    public  String BorrowedBook;
    public  String DateBorrowed;
    public  String Status;
    public  String DateReturned;
    
    public Transactions(int transactionNum, int studID,String studentName, int accNum,String bookName, String dateBorrowed, String status, String dateReturned ){
        this.TransactionNum = transactionNum; 
        this.StudentID = studID; 
        this.BorrowerName = studentName;
        this.AccessionNumber = accNum;
        this.BorrowedBook = bookName;
        this.DateBorrowed = dateBorrowed; 
        this.Status = status; 
        this.DateReturned = dateReturned; 
    }
    
    private static Connection conn = MysqlConn.getConnection();
    public static ArrayList<Transactions> getTransactions() {
        try {
            ArrayList<Transactions> transactions = new ArrayList<>();
            String query = "SELECT * FROM transactions";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()){
                transactions.add(new Transactions (rs.getInt("transaction_number"), rs.getInt("stud_id"), Students.returnNameByID(rs.getInt("stud_id")), rs.getInt("accession_number"),Books.returnBookName(rs.getInt("accession_number")), String.valueOf(rs.getDate("date_borrowed")), rs.getString("status"), String.valueOf(rs.getDate("date_returned"))));    
            }
            st.close();
            return transactions;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }
    public static boolean createTransactions(int entStudID, int entAccNum, String dateBorrowed, String status, String dateReturned) {
        try {
            String query = "INSERT INTO transactions (stud_id, accession_number, date_borrowed, status, date_returned)"
                     + "values (?,?,?,?,?)";
            PreparedStatement insertQuery = conn.prepareStatement(query);
            insertQuery.setInt(1, entStudID);
            insertQuery.setInt(2, entAccNum);
            insertQuery.setString(3, TheArchive.convertDate(dateBorrowed));
            insertQuery.setString(4, status);
            insertQuery.setString(5, TheArchive.convertDate(dateReturned));
            insertQuery.execute();
            query = "UPDATE books set book_availability = (?) where accession_number = (?)";
            PreparedStatement updateBook = conn.prepareStatement(query);
            updateBook.setString(1, status);
            updateBook.setInt(2, entAccNum);
            updateBook.execute();
            System.out.println("Insert into table transactions successful.");
            return true;
        } catch (SQLException e) {
            return false;

        }
    } 
     public static boolean updateTransactions(int entTransactionNum, int entStudId, int entAccNum, String dateBorrowed, String status, String dateReturned){
        try{
            String query = "UPDATE transactions set stud_id = (?), accession_number = (?), date_borrowed = (?), status = (?), date_returned =(?) where transaction_number = (?)";
            PreparedStatement updateQuery = conn.prepareStatement(query); 
            updateQuery.setInt (1, entStudId);
            updateQuery.setInt (2, entAccNum); 
            updateQuery.setString (3, TheArchive.convertDate(dateBorrowed)); 
            updateQuery.setString (4, status); 
            updateQuery.setString (5, TheArchive.convertDate(dateReturned)); 
            updateQuery.setInt (6, entTransactionNum); 
            updateQuery.execute();
            if (Books.updateBookStatus(entAccNum)) System.out.println("Update table transaction Successful.");
            return true;
        }
        catch(SQLException e){
            return false;
        }
    }
      public static Transactions getTransactionById(int transactionNum){
        try {
            Transactions transactions = null; 
            String query = "SELECT * FROM transactions where transaction_number = '" + transactionNum+"'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                transactions = new Transactions(rs.getInt("transaction_number"), rs.getInt("stud_id"), Students.returnNameByID(rs.getInt("stud_id")), rs.getInt("accession_number"),Books.returnBookName(rs.getInt("accession_number")), String.valueOf(rs.getDate("date_borrowed")), rs.getString("status"), String.valueOf(rs.getDate("date_returned")));
            }
            st.close();
            return transactions;
        } catch (SQLException e) {
            return null;
        }
        
    } 
       public static boolean deleteTransaction(int transactionNum){
        try {
            Books.updateBookStatus(getTransactionById(transactionNum).AccessionNumber);
            String query = " DELETE from transactions where transaction_number = " + transactionNum;
            PreparedStatement deleteQuery = conn.prepareStatement(query);
            deleteQuery.execute();
            System.out.println("Delete from table transactions Successful");
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
       public static ArrayList<Transactions> searchTransactions(String textSearch) {
        try {
            ArrayList <Transactions> transactions = new ArrayList();
            String query = "SELECT * FROM transactions where stud_id LIKE '" + textSearch + "%' OR transaction_number LIKE '" + textSearch + "%' OR accession_number LIKE '" + textSearch + "%'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                transactions.add(new Transactions(rs.getInt("transaction_number"), rs.getInt("stud_id"), Students.returnNameByID(rs.getInt("stud_id")), rs.getInt("accession_number"),Books.returnBookName(rs.getInt("accession_number")), String.valueOf(rs.getDate("date_borrowed")), rs.getString("status"), String.valueOf(rs.getDate("date_returned"))));
            }
            st.close();
            return transactions;
        } catch (SQLException e) { 
            return null;
        }
    }
    
    
    
}
