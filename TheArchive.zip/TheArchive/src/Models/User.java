
package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import thearchive.MysqlConn;

public class User {
    private static String DbUser;
    private static String DbPort;
    private static String DbName;
    private static String DbPass;
    public static Connection connection = MysqlConn.getConnection(); 
    public static void insertUser(String pass){
        try{
        DbPass = pass;
        String sql = "insert into user (DB_USER, DB_PORT, DB_NAME, DB_PASS)" +"values (?,?,?,?)";
        PreparedStatement insertUser = connection.prepareStatement(sql);
        insertUser.setString (1,MysqlConn.returnUser());
        insertUser.setString(2,MysqlConn.returnPort());
        insertUser.setString(3,MysqlConn.returnName());
        insertUser.setString(4,DbPass);
        insertUser.execute();
        }catch (Exception e){
            System.out.println("error eh ");
        }
    }
    public static String userPass(){
        return DbPass;
}
}
