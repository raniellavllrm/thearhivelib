/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import thearchive.MysqlConn;

/**
 *
 * @author raniellavillarama
 */
public class Students {

    public int StudentID;
    public String StudentName;
    public String StudentSName;
    public String StudentFName;
    public String StudentMName;
    public String DepartmentName;
    public String StudentContact;

    public Students(int studID, String studName, String studSName, String studFName, String studMName, String deptName, String studCont) {
        this.StudentID = studID;
        this.StudentName = studName;
        this.StudentSName = studSName;
        this.StudentFName = studFName;
        this.StudentMName = studMName;
        this.DepartmentName = deptName;
        this.StudentContact = studCont;
    }
    private static Connection conn = MysqlConn.getConnection();

    public static ArrayList<Students> getStudents() {
        try {
            ArrayList<Students> students = new ArrayList<>();
            String query = "SELECT * FROM student";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                students.add(new Students(rs.getInt("stud_id"), rs.getString("stud_name"), rs.getString("stud_sname"), rs.getString("stud_fname"), rs.getString("stud_mname"), rs.getString("stud_dept"), rs.getString("stud_contact")));
            }
            st.close();
            return students;
        } catch (SQLException e) {
            return null;
        }
    }

    public static boolean createLibrarian(int entStudID, String entSName, String entFName, String entMName, String entDept, String entContact) {
        try {
            if(!checkStudentID(entStudID)){
            String query = "INSERT INTO student (stud_id, stud_name, stud_sname, stud_fname, stud_mname, stud_dept, stud_contact)" + "values (?,?,?,?,?,?,?)";
            PreparedStatement insertQuery = conn.prepareStatement(query);
            String entName = entSName + ", " + entFName + " " + entMName + ".";
            insertQuery.setInt(1, entStudID);
            insertQuery.setString(2, entName);
            insertQuery.setString(3, entSName);
            insertQuery.setString(4, entFName);
            insertQuery.setString(5, entMName);
            insertQuery.setString(6, entDept);
            insertQuery.setString(7, entContact);
            insertQuery.execute();
            System.out.println("Insert into table student Successful.");
            return true;
            }else{
                JOptionPane.showMessageDialog(null, entStudID+"is already existing in our database. Please check your inputs.");
                return false;
            }
        } catch (SQLException e) {
            return false;
        }
    }
    public static boolean checkStudentID(int studentID) {
        ArrayList<Students> students = getStudents();
        for (int x = 0; x < students.size(); x++) {
            int studID = students.get(x).StudentID;
            if (studID == studentID) {
                return true;
            }
        }
        return false;
    }
    public static boolean updateStudent(int entStudID, String entSName, String entFName, String entMName, String entDept, String entContact) {
        try {
            String entName = entSName + ", " + entFName + " " + entMName + ".";
            String query = "UPDATE student set stud_name = (?), stud_sname = (?), stud_fname = (?), stud_mname = (?), stud_dept = (?), stud_contact = (?) where stud_id = (?)";
            PreparedStatement updateQuery = conn.prepareStatement(query);
            updateQuery.setString(1, entName);
            updateQuery.setString(2, entSName);
            updateQuery.setString(3, entFName);
            updateQuery.setString(4, entMName);
            updateQuery.setString(5, entDept);
            updateQuery.setString(6, entContact);
            updateQuery.setInt(7, entStudID);
            updateQuery.execute();
            System.out.println("Update table student Successful.");
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public static Students getStudentByID(int studentid) {
        try {
            Students students = null;
            String query = "SELECT * FROM student where stud_id = '" + studentid + "'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                students = new Students(rs.getInt("stud_id"), rs.getString("stud_name"), rs.getString("stud_sname"), rs.getString("stud_fname"), rs.getString("stud_mname"), rs.getString("stud_dept"), rs.getString("stud_contact"));
            }
            st.close();
            return students;
        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean deleteStudent(int entStudID) {
        try {

            Students students = getStudentByID(entStudID);
            String query = " DELETE from student where stud_id = '" + entStudID + "'";
            PreparedStatement deleteQuery = conn.prepareStatement(query);
            deleteQuery.execute();
            query = " DELETE from transactions where stud_id ='" + entStudID + "'";
            deleteQuery = conn.prepareStatement(query);
            deleteQuery.execute();
            System.out.println("Delete Successful");
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public static ArrayList<Students> searchStudent(String textSearch) {
        try {
            ArrayList<Students> students = new ArrayList();
            String query = "SELECT * FROM student where stud_name REGEXP '" + textSearch + "%' OR stud_dept REGEXP '" + textSearch + "%' OR stud_id LIKE '" + textSearch + "%'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                students.add(new Students(rs.getInt("stud_id"), rs.getString("stud_name"), rs.getString("stud_sname"), rs.getString("stud_fname"), rs.getString("stud_mname"), rs.getString("stud_dept"), rs.getString("stud_contact")));
            }
            st.close();
            return students;
        } catch (SQLException e) {
            return null;
        }
    }

    public static String returnNameByID(int studid) {
        String studentName = getStudentByID(studid).StudentName;
        return studentName;
    }
}
