/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import thearchive.MysqlConn;
import static thearchive.TheArchive.confirmEnterPass;

/**
 *
 * @author raniellavillarama
 */
public class Librarian {

    public String LibrarianUN;
    public String LibrarianFName;
    public String LibrarianMName;
    public String LibrarianSName;
    public String LibrarianName;
    public String LibContact;
    private String LibPass;

    public Librarian(String librarianUN, String librarianSurName, String librarianFirstName, String librarianMiddleName, String librarianName, String libContact, String libPass) {
        this.LibrarianUN = librarianUN;
        this.LibrarianSName = librarianSurName;
        this.LibrarianFName = librarianFirstName;
        this.LibrarianMName = librarianMiddleName;
        this.LibrarianName = librarianName;
        this.LibContact = libContact;
        this.LibPass = libPass;
    }

    private static Connection conn = MysqlConn.getConnection();

    public static ArrayList<Librarian> getLibrarian() {
        try {
            ArrayList<Librarian> librarian = new ArrayList<>();
            String query = "SELECT * FROM librarian";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                //System.out.println(rs.getString("name"));
                librarian.add(new Librarian(rs.getString("lib_username"), rs.getString("lib_surname"), rs.getString("lib_firstname"), rs.getString("lib_middlename"), rs.getString("lib_name"), rs.getString("lib_contact"), rs.getString("lib_password")));
            }
            st.close();
            return librarian;
        } catch (SQLException e) {
            return null;
        }
    }

    public static boolean checkUsername(String username1) {
        ArrayList<Librarian> librarian = getLibrarian();
        for (int x = 0; x < librarian.size(); x++) {
            String username = librarian.get(x).LibrarianUN;
            if (username.equals(username1)) {
                return true;
            }
        }
        return false;
    }

    public static boolean createLibrarian(String entLib, String entSName, String entFName, String entMName, String entCont, String entPass, String entConfirm) {
        try {
            if (confirmEnterPass(entPass, entConfirm)) {
                String query = "INSERT INTO librarian (lib_username, lib_surname, lib_firstname, lib_middlename, lib_name, lib_contact, lib_password)" + "values (?,?,?,?,?,?,?)";
                PreparedStatement insertQuery = conn.prepareStatement(query);
                String entName = entSName + ", " + entFName + " " + entMName + ".";
                insertQuery.setString(1, entLib);
                insertQuery.setString(2, entSName);
                insertQuery.setString(3, entFName);
                insertQuery.setString(4, entMName);
                insertQuery.setString(5, entName);
                insertQuery.setString(6, entCont);
                insertQuery.setString(7, entPass);

                insertQuery.execute();
                System.out.println("Insert into table librarian Successful.");
                return true;
            }

        } catch (SQLException e) {
            return false;

        }
        return false;
    }

    public static boolean updateLibrarian(String entLib, String entSName, String entFName, String entMName, String entCont, String entPass, String entConfirm) {
        try {
            Librarian librarians = getLibrarianByUN(entLib);
            String password = librarians.LibPass;
            if (confirmEnterPass(entPass, entConfirm) && confirmEnterPass(entPass, password)) {
                String entName = entSName + ", " + entFName + " " + entMName + ".";
                String query = "UPDATE librarian set lib_surname =(?), lib_firstname =(?), lib_middlename =(?), lib_name = (?), lib_contact = (?), lib_password = (?) where binary lib_username = (?)";
                PreparedStatement updateQuery = conn.prepareStatement(query);
                updateQuery.setString(1, entSName);
                updateQuery.setString(2, entFName);
                updateQuery.setString(3, entMName);
                updateQuery.setString(4, entName);
                updateQuery.setString(5, entCont);
                updateQuery.setString(6, entPass);
                updateQuery.setString(7, entLib);
                updateQuery.execute();
                System.out.println("Update table librarian Successful.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect Password.");
            }
        } catch (SQLException e) {
            return false;
        }
        return false;
    }

    public static Librarian getLibrarianByUN(String username) {
        try {
            Librarian librarians = null;
            String query = "SELECT * FROM librarian where binary lib_username = '" + username + "'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            while (rs.next()) {
                librarians = new Librarian(rs.getString("lib_username"), rs.getString("lib_surname"), rs.getString("lib_firstname"), rs.getString("lib_middlename"), rs.getString("lib_name"), rs.getString("lib_contact"), rs.getString("lib_password"));
            }
            st.close();
            return librarians;
        } catch (SQLException e) {
            return null;
        }

    }

    public static boolean deleteLibrarian(String username, String entPass, String entConfirm) {
        try {

            Librarian librarians = getLibrarianByUN(username);
            String password = librarians.LibPass;
            if (confirmEnterPass(entPass, entConfirm) && confirmEnterPass(entPass, password)) {
                String query = " DELETE from librarian where binary lib_username = '" + username + "'";
                PreparedStatement deleteQuery = conn.prepareStatement(query);
                deleteQuery.execute();
                System.out.println("Delete Successful");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect Password.");
                return false;
            }
        } catch (SQLException e) {
            return false;
        }
    }

    public static boolean saveEditLibrarian(String tempentLib, String entLib, String entSName, String entFName, String entMName, String entCont, String entPass, String entConfirm, String dialogPass) {
        try {
            Librarian librarians = getLibrarianByUN(tempentLib);
            String password = librarians.LibPass;
            if (confirmEnterPass(password, dialogPass) && confirmEnterPass(entPass, entConfirm)) {
                String entName = entSName + ", " + entFName + " " + entMName + ".";
                String query = "UPDATE librarian set lib_username= (?), lib_surname =(?), lib_firstname =(?), lib_middlename =(?), lib_name = (?), lib_contact = (?), lib_password = (?) where binary lib_username = (?)";
                PreparedStatement updateQuery = conn.prepareStatement(query);
                updateQuery.setString(1, entLib);
                updateQuery.setString(2, entSName);
                updateQuery.setString(3, entFName);
                updateQuery.setString(4, entMName);
                updateQuery.setString(5, entName);
                updateQuery.setString(6, entCont);
                updateQuery.setString(7, entPass);
                updateQuery.setString(8, tempentLib);
                updateQuery.execute();
                System.out.println("Update table librarian Successful.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect Password.");
                return false;
            }
        } catch (SQLException e) {
            return false;
        }
    }

    public static String getPrivPass(int num) {
        ArrayList<Librarian> Librarian = getLibrarian();
        return Librarian.get(num).LibPass;
    }

    public static String getPassword(String username) {
        Librarian librarian = getLibrarianByUN(username);
        return librarian.LibPass;
    }

    public static Boolean checkLibrarian(String username, String password) {
        ArrayList<Librarian> librarian = getLibrarian();
        for (int x = 0; x < librarian.size(); x++) {
            if (username.equals(librarian.get(x).LibrarianUN) && password.equals(librarian.get(x).LibPass)) {
                return true;
            }
        }
        return false;
    }

}
