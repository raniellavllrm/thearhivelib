/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thearchive;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author raniellavillarama
 */
public class TheArchive {

    public static int maxTrial = 3;

    public static String passwordConverter(char[] pass) {
        String password = "";
        for (int x = 0; x < pass.length; x++) {
            password = password + pass[x];
        }
        return password;
    }

    public static Boolean checkChar(char e) {
        return (Character.isLetter(e) || Character.isWhitespace(e) || Character.isISOControl(e));
    }

    public static Boolean checkLength(char e, String str, int limit) {
        return (Character.isISOControl(e) || str.length() < limit);
    }

    public static Boolean checkNumber(String str, int limit, char e) {
        if (Character.isISOControl(e)) {
            return true;
        }
        return (Character.isDigit(e) && str.length() < limit);
    }

    public static Boolean checkSpecials(String str) {
        Pattern sPattern = Pattern.compile("\"[$&+,:;=?@#|'<>.-^*()%!]\"");
        Matcher sMatcher = sPattern.matcher(str);
        return (!sMatcher.matches());
    }

    public static Boolean checkPassword(char[] pass, char pass2) {
        for (int x = 0; x < pass.length; x++) {
            if (pass[x] == pass2) {
                return true;
            }
        }
        return false;
    }

    public static Boolean confirmEnterPass(String pass1, String pass2) {
        return (pass1.equals(pass2));
    }

    public static String returnPass(String password) {
        String character = "";
        for (int x = 0; x < password.length(); x++) {
            character = character + "*";
        }
        return character;
    }

    public static Boolean ansLogout() {
        int a = JOptionPane.showConfirmDialog(null, "Any unsaved changes would be dropped. \nWould you like to continue?");
        return (a == JOptionPane.YES_OPTION);
    }

    public static void newWindow(JFrame thisFrame, JFrame frame) {
        thisFrame.dispose();
        frame.setVisible(true);
    }

    public static void buttonsEnabled(JButton button1, JButton button2, JButton button3, Boolean stat) {
        button1.setEnabled(stat);
        button2.setEnabled(stat);
        button3.setEnabled(stat);
    }

    public static void checkDate(JTextField dateText, KeyEvent ev) {
        if (!(Character.isISOControl(ev.getKeyChar()))) {
            String str = dateText.getText();
            String str1 = str;
            str1 = str.replaceAll("-", "");
            if (str1.length() % 2 == 0 && str.length() != 0) {
                str = str + "-";
                dateText.setText(str);
            }
        }
    }

    public static Boolean dateAfter(String dateBorrowed, String dateReturned) {

        LocalDate dt1 = LocalDate.parse(convertDate(dateBorrowed));
        LocalDate dt2 = LocalDate.parse(convertDate(dateReturned));
        System.out.println(dt1.isBefore(dt2));
        if (!dt1.isBefore(dt2)) {
            JOptionPane.showMessageDialog(null, "Invalid return date. Please check again.");
            return false;
        }
        return true;
    }

    public static String convertDate(String inputDate) {
        if (!inputDate.isEmpty()) {
            DateFormat df = new SimpleDateFormat("mm-dd-yy");
            DateFormat outputformat = new SimpleDateFormat("yyyy-mm-dd");
            Date date = null;
            String output = null;
            try {
                date = df.parse(inputDate);
                output = outputformat.format(date);
                return output;
            } catch (ParseException pe) {
                return ("00-00-00");
            }
        }
        return "00-00-00";
    }

    public static String convertDateToText(String inputDate) {
        if (!inputDate.isEmpty() && !inputDate.equals("null")) {
            DateFormat df = new SimpleDateFormat("yyyy-mm-dd");
            DateFormat outputformat = new SimpleDateFormat("mm-dd-yy");
            Date date = null;
            String output = null;
            try {
                date = df.parse(inputDate);
                output = outputformat.format(date);
                return output;
            } catch (ParseException pe) {
                pe.printStackTrace();
                return null;
            }
        }
        return "";
    }

    public static void messageDialog(String tableName, ActionEvent evt, Boolean state, JButton add, JButton update, JButton delete) {
        String message = tableName;
        if (evt.getSource() == add && state) {
            message = message + " successfully added!";
        } else if (evt.getSource() == update && state) {
            message = message + " successfully updated!";
        } else if (evt.getSource() == delete && state) {
            message = message + " successfully deleted!";
        } else if (!state) {
            message = "The system has encountered a problem reading your inputs. Please try again!";
        }
        JOptionPane.showMessageDialog(null, message);
    }

    public static Boolean deleteQues() {
        int a = JOptionPane.showConfirmDialog(null, "Would you like to delete this?");
        return (a == JOptionPane.YES_OPTION);
    }
}
