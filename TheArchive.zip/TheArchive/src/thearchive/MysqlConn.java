/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thearchive;

import Models.Admin;
import Models.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author raniellavillarama
 */
public class MysqlConn {

    private static final String DB_NAME = "librarymanagement";
    private static String DB_PASS = "";
    private static final String DB_USER = "root";
    private static final String DB_PORT = "3306";
    private static final String SETCONNECTION_STRING = "jdbc:mysql://localhost:" + DB_PORT + "/mysql?zeroDateTimeBehavior=convertToNull";
    private static final String GETCONNECTION_STRING = "jdbc:mysql://localhost:" + DB_PORT + "/" + DB_NAME + "?zeroDateTimeBehavior=convertToNull";

    public static String returnName() {
        return DB_NAME;
    }

    public static String returnUser() {
        return DB_USER;
    }

    public static String returnPort() {
        return DB_PORT;
    }

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(GETCONNECTION_STRING, DB_USER, DB_PASS);
            return connection;
        } catch (Exception e) {
            System.out.println("The system had encountered issues connecting to the database. Let The Archive secure the connection.");
            return connection;
        }
    }

    public static void setConnection(String dbPass) {
        DB_PASS = dbPass;
        try {
            Connection connection = DriverManager.getConnection(SETCONNECTION_STRING, DB_USER, DB_PASS);
            if (!checkConnection(dbPass)) {
                if (dbExist(DB_NAME)) {
                    int a = JOptionPane.showConfirmDialog(null, "There is an existing " + DB_NAME + ". If you wish to proceed,\n the existing database would be dropped.");
                    Statement statement = connection.createStatement();
                    if (a == JOptionPane.YES_OPTION) {
                        String query = "DROP DATABASE " + DB_NAME + ";";
                        statement.executeUpdate(query);
                    }
                }
                String sql = "CREATE DATABASE " + DB_NAME;
                Statement statement = connection.prepareStatement(sql);
                statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, DB_NAME + " Database has been created successfully", "System Message", JOptionPane.INFORMATION_MESSAGE);
                Table.createTables();
                User.insertUser(DB_PASS);
                Admin.createAdmin();
            }

        } catch (Exception e) {
        }
    }

    public static boolean checkConnection(String dbPass) {
        try {
            DB_PASS = dbPass;
            if (dbExist(DB_NAME)) {
                Connection connection = DriverManager.getConnection(SETCONNECTION_STRING, DB_USER, DB_PASS);
                String query = "use " + DB_NAME + ";";
                Statement statement = connection.createStatement();
                statement.executeUpdate(query);
                query = "select * from " + Table.returnTable(5);
                ResultSet resultset = statement.executeQuery(query);
                while (resultset.next()) {
                    if (resultset.getString("DB_PASS").equals(dbPass) && resultset.getString("DB_USER").equals(DB_USER)) {
                        DB_PASS = resultset.getString("DB_PASS");
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("An existing database named " + DB_NAME + " already exists. ");
        }
        return false;
    }

    public static boolean dbExist(String dbName) {
        try {
            Connection connection = DriverManager.getConnection(SETCONNECTION_STRING, DB_USER, DB_PASS);
            ResultSet result = connection.getMetaData().getCatalogs();
            while (result.next()) {
                String databaseName = result.getString(1);
                if (databaseName.equals(dbName)) {
                    return true;
                }
            }
        } catch (Exception e) {
            System.out.println("It seems there is an error.");
        }
        return false;
    }
}
