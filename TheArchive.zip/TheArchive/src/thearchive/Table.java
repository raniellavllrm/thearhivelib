
package thearchive;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Table {
    private static final String[] TableName =  {"librarian","student","books","transactions","admin","user"};
    private static final String[] LibrarianHead = {"lib_username varchar (20)","lib_surname varchar (100)","lib_firstname varchar (100)","lib_middlename varchar (100)","lib_name varchar (100)","lib_contact varchar (11)","lib_password varchar(12)"}; 
    private static final String[] StudentHead = {"stud_id int (8)","stud_name varchar (100)","stud_sname varchar (50)","stud_fname varchar (50)","stud_mname varchar (50)","stud_dept varchar (50)","stud_contact varchar (11)"};
    private static final String[] BookHead = {"accession_number int (8) PRIMARY KEY AUTO_INCREMENT","book_name varchar (100)","book_author varchar (100)","book_snameauthor varchar (50)","book_fnameauthor varchar (50)","book_mnameauthor varchar (50)","isbn varchar (100)","book_availability varchar(20)"};
    private static final String[] TransactionHead ={"transaction_number int (8) PRIMARY KEY AUTO_INCREMENT","stud_id int (8)","accession_number int (8)","date_borrowed date", "status varchar (15)","date_returned date"};
    private static final String[] AdminHead ={"admin varchar (20)","admin_password varchar (12)"};
    private static final String[] UserHead ={"DB_USER varchar (100)", "DB_PORT varchar (100)", "DB_NAME varchar (100)", "DB_PASS varchar (100)"};
    
    private static Connection conn = MysqlConn.getConnection();
    public static void createTables(){
        try{
        Statement createSt = conn.createStatement();
        for (int x=0; x<TableName.length;x++){
            String createSql = "create table ";
            switch (x){
                case 0: 
                    createSql =createSql + TableName[x]+"(";
                    for (int y=0; y<LibrarianHead.length;y++){
                        createSql = createSql + LibrarianHead[y];
                        if (y != LibrarianHead.length - 1) createSql = createSql +" ,";
                    }
                break;
                case 1: 
                    createSql = createSql + TableName[x]+"(";
                    for (int y=0; y<StudentHead.length;y++){
                        createSql = createSql + StudentHead[y];
                        if (y != StudentHead.length - 1) createSql = createSql +" ,";
                    }
                break; 
                case 2: 
                    createSql = createSql + TableName[x]+"(";
                    for (int y=0; y<BookHead.length;y++){
                        createSql = createSql + BookHead[y];
                        if (y != BookHead.length - 1) createSql = createSql +" ,";
                    }
                break;
                case 3: 
                    createSql = createSql + TableName[x]+"(";
                    for (int y=0; y<TransactionHead.length;y++){
                        createSql = createSql + TransactionHead[y];
                        if (y != TransactionHead.length - 1) createSql = createSql +" ,";
                    }
                break; 
                case 4:
                    createSql = createSql + TableName[x]+"(";
                    for (int y=0; y<AdminHead.length;y++){
                        createSql = createSql + AdminHead[y];
                        if (y != AdminHead.length - 1) createSql = createSql +" ,";
                    }
                break; 
                case 5:
                    createSql = createSql + TableName[x]+"(";
                    for (int y=0; y<UserHead.length;y++){
                        createSql = createSql + UserHead[y];
                        if (y != UserHead.length - 1) createSql = createSql +" ,";
                    }
                break; 
            }
            createSql = createSql + ");";
            createSt.executeUpdate(createSql); 
        }
        }catch(Exception e){
            System.out.println("ERROR DUH");
            System.out.println(e);
        }
    }
    
    
    public static String returnTable(int x){
        return TableName[x];
    }

    
}